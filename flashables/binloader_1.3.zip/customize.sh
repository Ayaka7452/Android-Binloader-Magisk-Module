# installs binloader using module mode instead of single file mode
# this file is a part of binloader

defpath=/data/binloader
defmgp=/data/adb/modules/binloader
bootcfg=/data/adb/service.d/blc_conf.sh


# Creates work directories:
mkdir $defpath
mkdir $defpath/mods
mkdir $defpath/configs
mkdir $defpath/tmp
 
# Perm fixes and symlink creation:
echo "#!/bin/sh" >> $bootcfg
echo "chmod 0755 $defmgp/system/bin/binloader" >> $bootcfg
echo "ln -s $defmgp/system/bin/binloader $MODDIR/system/bin/blcore" >> $bootcfg
echo "rm /data/adb/service.d/blc_conf.sh" >> $bootcfg
chmod 0755 $bootcfg

# Creates configs:
echo $defpath > $defpath/configs/defpath

# Set installed mark:
echo 1 > $defpath/configs/inststate

# Usage ouput
echo "Reboot and type binloader command in a terminal emulator to initialize the module"

